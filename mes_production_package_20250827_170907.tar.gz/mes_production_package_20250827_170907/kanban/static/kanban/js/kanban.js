// Kanban 模組腳本文件
document.addEventListener('DOMContentLoaded', function() {
    console.log('Kanban module loaded');
});
