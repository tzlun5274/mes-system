# MES 系統生產環境部署套件

## 快速部署

1. **解壓縮套件**
   ```bash
   tar -xzf mes_production_package_*.tar.gz
   cd mes_production_package_*
   ```

2. **修改配置**
   ```bash
   cp .env.example .env
   nano .env
   ```
   
   必須修改的項目：
   - `ALLOWED_HOSTS`: 加入您的伺服器 IP
   - `HOST_IP`: 您的伺服器 IP
   - `DATABASE_PASSWORD`: 安全的資料庫密碼
   - `REDIS_PASSWORD`: 安全的 Redis 密碼
   - `SUPERUSER_PASSWORD`: 安全的管理員密碼

3. **執行部署**
   ```bash
   sudo ./全新部署.sh
   ```

4. **驗證部署**
   ```bash
   sudo systemctl status mes.service
   curl http://localhost
   ```

## 系統需求

- Ubuntu 20.04 LTS 或更新版本
- 至少 4GB 記憶體
- 至少 10GB 硬碟空間
- 網路連線

## 訪問地址

部署完成後：
- 主網站: http://YOUR_SERVER_IP
- 管理後台: http://YOUR_SERVER_IP/admin

## 故障排除

如果遇到問題，請檢查：
1. `.env` 檔案配置是否正確
2. 服務狀態: `sudo systemctl status mes.service`
3. 日誌: `sudo journalctl -u mes.service -f`

## 技術支援

如有問題，請聯絡技術支援團隊。
