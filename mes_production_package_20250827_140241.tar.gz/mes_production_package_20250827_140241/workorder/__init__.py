"""
工單管理模組
負責工單的建立、管理、派工、報工等功能
"""

# 註冊信號處理器
default_app_config = 'workorder.apps.WorkorderConfig'
