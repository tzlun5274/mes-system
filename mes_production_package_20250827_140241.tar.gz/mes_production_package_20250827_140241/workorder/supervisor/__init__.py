"""
主管功能子模組 (Supervisor Management Module)
負責主管相關功能，包含審核管理、統計分析、異常處理、資料維護等
"""

default_app_config = 'workorder.supervisor.apps.SupervisorConfig' 