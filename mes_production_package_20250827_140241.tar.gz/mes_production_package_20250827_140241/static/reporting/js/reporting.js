// Reporting 模組腳本文件
document.addEventListener('DOMContentLoaded', function() {
    console.log('Reporting module loaded');
});
