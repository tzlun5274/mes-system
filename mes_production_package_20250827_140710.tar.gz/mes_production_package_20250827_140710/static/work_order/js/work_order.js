// work_order 模組的 JavaScript 邏輯
document.addEventListener('DOMContentLoaded', function() {
    console.log('work_order module loaded');
});
