// Process 模組腳本文件
document.addEventListener('DOMContentLoaded', function() {
    console.log('Process module loaded');
});
