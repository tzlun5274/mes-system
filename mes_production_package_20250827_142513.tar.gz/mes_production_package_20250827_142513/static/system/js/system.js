// system 模組的 JavaScript 邏輯
document.addEventListener('DOMContentLoaded', function() {
    console.log('system module loaded');
});
