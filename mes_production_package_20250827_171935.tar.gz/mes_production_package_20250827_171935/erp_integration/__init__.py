# erp_integration 模組初始化文件
