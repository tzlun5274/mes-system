// ERP Integration 模組腳本文件
document.addEventListener('DOMContentLoaded', function() {
    console.log('ERP Integration module loaded');
});
