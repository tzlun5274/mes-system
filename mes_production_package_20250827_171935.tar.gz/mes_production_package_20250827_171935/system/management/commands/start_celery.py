from django.core.management.base import BaseCommand
import subprocess
import os
import time

class Command(BaseCommand):
    help = '啟動 MES 系統 Celery 服務'

    def handle(self, *args, **options):
        self.stdout.write("=" * 50)
        self.stdout.write("啟動 MES 系統 Celery 服務")
        self.stdout.write("=" * 50)
        
        # 檢查 Redis
        self.stdout.write("\n1. 檢查 Redis 服務...")
        try:
            result = subprocess.run(['redis-cli', 'ping'], capture_output=True, text=True)
            if 'PONG' in result.stdout:
                self.stdout.write("✓ Redis 連接正常")
            else:
                self.stdout.write("⚠ Redis 未運行，嘗試啟動...")
                subprocess.run(['sudo', 'systemctl', 'start', 'redis-server'])
                time.sleep(2)
                result = subprocess.run(['redis-cli', 'ping'], capture_output=True, text=True)
                if 'PONG' in result.stdout:
                    self.stdout.write("✓ Redis 啟動成功")
                else:
                    self.stdout.write("✗ Redis 啟動失敗")
                    return
        except Exception as e:
            self.stdout.write(f"✗ Redis 檢查失敗: {e}")
            return
        
        # 停止現有的 Celery 進程
        self.stdout.write("\n2. 停止現有 Celery 進程...")
        try:
            subprocess.run(['pkill', '-f', 'celery.*worker'], capture_output=True)
            subprocess.run(['pkill', '-f', 'celery.*beat'], capture_output=True)
            time.sleep(2)
            self.stdout.write("✓ 現有進程已停止")
        except Exception as e:
            self.stdout.write(f"⚠ 停止進程時發生錯誤: {e}")
        
        # 啟動 Celery Worker
        self.stdout.write("\n3. 啟動 Celery Worker...")
        try:
            worker_cmd = [
                'python3', '-m', 'celery', '-A', 'mes_config', 
                'worker', '--loglevel=info'
            ]
            worker_process = subprocess.Popen(
                worker_cmd,
                stdout=open('celery_worker.log', 'w'),
                stderr=subprocess.STDOUT,
                preexec_fn=os.setsid
            )
            self.stdout.write(f"✓ Celery Worker 已啟動 (PID: {worker_process.pid})")
        except Exception as e:
            self.stdout.write(f"✗ Celery Worker 啟動失敗: {e}")
            return
        
        # 等待 Worker 啟動
        time.sleep(3)
        
        # 啟動 Celery Beat
        self.stdout.write("\n4. 啟動 Celery Beat...")
        try:
            beat_cmd = [
                'python3', '-m', 'celery', '-A', 'mes_config', 
                'beat', '--loglevel=info', 
                '--scheduler', 'django_celery_beat.schedulers:DatabaseScheduler'
            ]
            beat_process = subprocess.Popen(
                beat_cmd,
                stdout=open('celery_beat.log', 'w'),
                stderr=subprocess.STDOUT,
                preexec_fn=os.setsid
            )
            self.stdout.write(f"✓ Celery Beat 已啟動 (PID: {beat_process.pid})")
        except Exception as e:
            self.stdout.write(f"✗ Celery Beat 啟動失敗: {e}")
            return
        
        # 等待 Beat 啟動
        time.sleep(3)
        
        # 檢查進程狀態
        self.stdout.write("\n5. 檢查進程狀態...")
        try:
            result = subprocess.run(['ps', 'aux'], capture_output=True, text=True)
            lines = result.stdout.split('\n')
            
            worker_found = False
            beat_found = False
            
            for line in lines:
                if 'celery.*worker' in line and 'grep' not in line:
                    self.stdout.write(f"✓ Celery Worker: {line.strip()}")
                    worker_found = True
                elif 'celery.*beat' in line and 'grep' not in line:
                    self.stdout.write(f"✓ Celery Beat: {line.strip()}")
                    beat_found = True
            
            if worker_found and beat_found:
                self.stdout.write("\n✓ Celery 服務啟動成功！")
            else:
                self.stdout.write("\n⚠ 部分服務可能未正常啟動")
                
        except Exception as e:
            self.stdout.write(f"✗ 無法檢查進程: {e}")
        
        self.stdout.write("\n" + "=" * 50)
        self.stdout.write("啟動完成")
        self.stdout.write("=" * 50) 