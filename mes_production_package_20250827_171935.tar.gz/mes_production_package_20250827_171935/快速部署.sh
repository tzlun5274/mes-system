#!/bin/bash

echo "=== MES 系統快速部署 ==="
echo ""

# 檢查 .env 檔案
if [ ! -f ".env" ]; then
    echo "❌ 未找到 .env 檔案"
    echo "請先修改 .env 檔案中的配置"
    exit 1
fi

# 檢查是否以 root 權限執行
if [ "$EUID" -ne 0 ]; then
    echo "❌ 請使用 sudo 執行此腳本"
    exit 1
fi

echo "開始部署..."
sudo ./全新部署.sh

echo ""
echo "✅ 部署完成！"
echo "訪問地址: http://$(grep 'HOST_IP=' .env | cut -d'=' -f2)"
echo "管理後台: http://$(grep 'HOST_IP=' .env | cut -d'=' -f2)/admin"
